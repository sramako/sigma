Thanks for downloading this theme!

Theme Name: Shuffle
Theme URL: https://bootstrapmade.com/bootstrap-3-one-page-template-free-shuffle/
Author: BootstrapMade
Author URL: https://bootstrapmade.com